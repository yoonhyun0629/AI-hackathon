<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OpenAI SSE Example</title>
</head>
<body>
    <form id="questionForm">
        <input type="text" id="inputQuestion" placeholder="Ask something...">
        <button type="submit">Submit</button>
    </form>
    <div id="response">Waiting for input...</div>
    <div id="waitingMessage" style="display: none;">대기 중...</div>

    <script>
        const questionForm = document.getElementById("questionForm");
        const responseDiv = document.getElementById("response");
        const waitingMessage = document.getElementById("waitingMessage");

        questionForm.addEventListener("submit", function(event) {
            event.preventDefault();
            const question = document.getElementById("inputQuestion").value;

            if (question) {
                waitingMessage.style.display = "block";
                responseDiv.textContent = "";

                const evtSource = new EventSource("gpt_server.php?question=" + encodeURIComponent(question));
                evtSource.onmessage = function(event) {
                    const responseData = JSON.parse(event.data);
                    responseDiv.textContent = responseData.choices[0].text.trim();
                    waitingMessage.style.display = "none";
                    evtSource.close();
                };
            }
        });

        evtSource.onmessage = function (event) {
    const div = document.getElementById("response");
    let text;
    try {
        const jsonData = JSON.parse(event.data);
        if (jsonData.choices && jsonData.choices[0] && jsonData.choices[0].text) {
            text = jsonData.choices[0].text;
            div.innerHTML += text;
        } else if (jsonData === "ERROR") {
            div.innerHTML += "API에서 오류가 발생했습니다.";
        } else {
            div.innerHTML += "알 수 없는 오류가 발생했습니다.";
        }
    } catch (e) {
        div.innerHTML += "응답 처리 중 오류가 발생했습니다.";
    }
};

    </script>
</body>
</html>
