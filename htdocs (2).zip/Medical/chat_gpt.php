<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>의약품 조회</title>
    <link rel="stylesheet" type="text/css" href="./css/main.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <?php include './lib/header.php';?>
    <section class="info_section">
        <div class="info_text">
            <p>AI Prescription</p>
            <p>ChatGPT 기반의 의약품 처방 가이드 솔루션</p>
        </div>
    </section>
    <section class="menu_list">
        <div class="menu_array">
            <ul>
                <li><a href="#">솔루션</a></li>
                <li><a href="./med_search.php">의약품 조회</a></li>
                <li><a href="./chat_gpt.php"  class="select_menu">AI 처방전</a></li>
            </ul>
        </div>
    </section>
    <section class="title_section">
        <div class="title_box">
            <p class="s_title">AI 처방전</p>
            <i class="under_line">&nbsp;</i>
            <p class="s_title_info">자신의 상태나 복용하는 약을 물어보세요.</p>
        </div>
    </section>
    <section class="gpt_section">
        <div class="gpt_wrap">
            
        </div>
    </section>
</body>
</html>