<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>의약품 조회</title>
    <link rel="stylesheet" type="text/css" href="./css/main.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <?php include './lib/header.php';?>
    <section class="info_section">
        <div class="info_text">
            <p>Medication Search</p>
            <p>자신이 복용하는 약이나 처방 받은 약의 정보를 확인해보세요.</p>
        </div>
    </section>
    <section class="menu_list">
        <div class="menu_array">
            <ul>
                <li><a href="#">솔루션</a></li>
                <li><a href="./med_search.php" class="select_menu">의약품 조회</a></li>
                <li><a href="./chat_gpt.php">AI 처방전</a></li>
            </ul>
        </div>
    </section>
    <section class="title_section">
        <div class="title_box">
            <p class="s_title">의약품 조회</p>
            <i class="under_line">&nbsp;</i>
            <p class="s_title_info">의약품명이나 제조사명으로 위약품을 조회해보세요.</p>
        </div>
    </section>
    <section class="search_area">
        <div class="search_warp">
            <div class="search_line">
                <select class="select_box" id="searchOption">
                    <option value="itmNm">품목명</option>
                    <option value="mnfEntpNm">제조사명</option>
                </select>
                <p class="search_input"><input type="text" id="searchKeyword" placeholder="검색어를 입력해주세요." onkeypress="handleKeyPress(event)"></p>
                <p class="search_button"><button onclick="searchMedicine()">검색</button></p>
            </div>
            <div class="medi_table_warp">
                <table class="medi_table" id="medicineTable">
                    <tr class="title_medi">
                        <th class="table_title">번호</th>
                        <th class="table_title">품목명</th>
                        <th class="table_title">제조업체</th>
                        <th class="table_title">용도</th>
                        <th class="table_title">처방전 여부</th>
                    </tr>
                    <tr class="medi"><td>1</td><td><a href="#">어린이용타이레놀정80밀리그람</a></td><td>(주)한국얀센</td><td>해열·진통·소염제</td><td>일반</td></tr><tr class="medi"><td>2</td><td><a href="#">어린이타이레놀현탁액</a></td><td>(주)한국얀센</td><td>해열·진통·소염제</td><td>일반</td></tr><tr class="medi"><td>3</td><td><a href="#">어린이타이레놀현탁액_</a></td><td>(주)한국얀센</td><td>해열·진통·소염제</td><td>일반</td></tr><tr class="medi"><td>4</td><td><a href="#">어린이타이레놀현탁액_</a></td><td>(주)한국얀센</td><td>해열·진통·소염제</td><td>일반</td></tr><tr class="medi"><td>5</td><td><a href="#">어린이타이레놀현탁액_</a></td><td>(주)한국얀센</td><td>해열·진통·소염제</td><td>일반</td></tr><tr class="medi"><td>6</td><td><a href="#">어린이타이레놀현탁액_</a></td><td>(주)한국얀센</td><td>해열·진통·소염제</td><td>일반</td></tr><tr class="medi"><td>7</td><td><a href="#">타이레놀옥시캡슐</a></td><td>(주)한국얀센</td><td>합성마약</td><td>전문</td></tr><tr class="medi"><td>8</td><td><a href="#">타이레놀8시간이알서방정</a></td><td>(주)한국얀센</td><td>해열·진통·소염제</td><td>일반</td></tr><tr class="medi"><td>9</td><td><a href="#">타이레놀8시간이알서방정325밀리그람</a></td><td>(주)한국얀센</td><td>해열·진통·소염제</td><td>일반</td></tr><tr class="medi"><td>10</td><td><a href="#">타이레놀정160밀리그람</a></td><td>(주)한국얀센</td><td>해열·진통·소염제</td><td>일반</td></tr>
                </table>
                <div class="numer_nav">
                    <div class="pagination">
                        <a href="#">&laquo;</a>
                        <a href="#" class="n_nav_select">1</a>
                        <a href="#">2</a>
                        <a href="#">3</a>
                        <a href="#">4</a>
                        <a href="#">5</a>
                        <a href="#">6</a>
                        <a href="#">&raquo;</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>
</html>

<script>
	function handleKeyPress(event) {
    if (event.key === 'Enter') {
        searchMedicine();
    }
}
function searchMedicine() {
    var selectedOption = document.getElementById("searchOption").value;
    var keyword = document.getElementById("searchKeyword").value;

    // AJAX 요청을 보냄
    $.ajax({
        type: "GET",
        url: "./lib/med_search_ajax.php", // PHP 스크립트 파일 경로
        data: {
            searchOption: selectedOption,
            searchKeyword: keyword
        },
        success: function(response) {
		    // 성공적으로 응답을 받으면, 결과를 테이블에 업데이트
		    // 첫 번째 tr 요소를 제외한 나머지 tr 요소만 업데이트
		    $("#medicineTable tr:not(:first)").remove(); // 기존 테이블 내용 삭제
		    $("#medicineTable").append(response); // 새로운 데이터로 업데이트
		},

        error: function() {
            alert("검색 중 오류가 발생했습니다.");
        }
    });
}
</script>
