<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<style type="text/css">
		.box{
			position: relative;
			width: 800px;
			height: 700px;
		}
	</style>
</head>
<body>
	<div class="box">
		<img src="./assets/images/main.gif">
	</div>
</body>
</html>