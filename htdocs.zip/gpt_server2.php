<?php
@ini_set('zlib.output_compression', 0);
ob_implicit_flush(true);
ob_end_flush();

header("Content-Type: text/event-stream");
header("Cache-Control: no-cache");

$api_key = "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";
$prompt = $_GET["question"];

$url = "https://api.openai.com/v1/engines/text-davinci-003/completions";

$data = array(
    "prompt" => $prompt,
    "max_tokens" => 3000,
    "temperature" => 0.2
);


$data_string = json_encode($data);

$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($curl, CURLOPT_HTTPHEADER, array(
    "Content-Type: application/json",
    "Authorization: Bearer " . $api_key,
    "Content-Length: " . strlen($data_string))
);

curl_setopt($curl, CURLOPT_WRITEFUNCTION, function ($curl, $data) {
    $cleanedData = str_replace(["\n", "\r"], '', $data);
    echo "data: {$cleanedData}\n\n";
    ob_flush();
    flush();
    return strlen($data);
});


curl_exec($curl);
curl_close($curl);
?>
