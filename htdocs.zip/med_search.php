<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>의약품 조회</title>
    <link rel="stylesheet" type="text/css" href="./css/main.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
    #inputQuestion, #questionForm button {
        display: none;  /* input과 button 숨기기 */
    }
    .typing {  
        display: inline-block; 
        animation-name: cursor; 
        animation-duration: 0.3s; 
        animation-iteration-count: infinite; 
    } 
    @keyframes cursor { 
        0% { border-right: 1px solid #fff } 
        50% { border-right: 1px solid #000 } 
        100% { border-right: 1px solid #fff } 
    }
</style>
</head>
<body>
    <?php include './lib/header.php';?>
    <section class="info_section">
        <div class="info_text">
            <p>Medication Search</p>
            <p>자신이 복용하는 약이나 처방 받은 약의 정보를 확인해보세요.</p>
        </div>
    </section>
    <section class="menu_list">
        <div class="menu_array">
            <ul>
                <li><a href="#">솔루션</a></li>
                <li><a href="./med_search.php" class="select_menu">의약품 조회</a></li>
                <li><a href="./chat_gpt.php">AI 처방전</a></li>
            </ul>
        </div>
    </section>
    <section class="title_section">
        <div class="title_box">
            <p class="s_title">의약품 조회</p>
            <i class="under_line">&nbsp;</i>
            <p class="s_title_info">의약품명이나 제조사명으로 의약품을 조회해보세요.</p>
        </div>
    </section>
    <section class="search_area">
        <div class="search_warp">
            <div class="search_line">
                <select class="select_box" id="searchOption">
                    <option value="itmNm">품목명</option>
                    <option value="mnfEntpNm">제조사명</option>
                </select>
                <p class="search_input"><input type="text" id="searchKeyword" placeholder="검색어를 입력해주세요." onkeypress="handleKeyPress(event)"></p>
                <p class="search_button"><button onclick="searchMedicine()">검색</button></p>
            </div>
            <form id="questionForm">
        <input type="text" id="inputQuestion" placeholder="Ask something...">
        <button type="submit">Submit</button>
    </form>
    
    
            <div class="medi_table_warp">
                <div class="gpt_prompt">
                    <div class="gpt_logo">
                        <p><img src="./assets/images/gpt.png"></p>
                    </div>
                    <div class="gpt_text">
                        <div id="response">약 이름을 검색하시면 상세내용을 알려드릴게요 !</div>
                        <div id="waitingMessage" style="display: none;">대기 중...</div>
                        <div id="response" class="typing"></div>
                    </div>
                </div>
                <table class="medi_table" id="medicineTable">
                    <tr class="title_medi">
                        <th class="table_title">번호</th>
                        <th class="table_title">품목명</th>
                        <th class="table_title">제조업체</th>
                        <th class="table_title">용도</th>
                        <th class="table_title">처방전 여부</th>
                    </tr>
                    <tr class="medi"><td>1</td><td><a href="#">어린이용타이레놀정80밀리그람</a></td><td>(주)한국얀센</td><td>해열·진통·소염제</td><td>일반</td></tr><tr class="medi"><td>2</td><td><a href="#">어린이타이레놀현탁액</a></td><td>(주)한국얀센</td><td>해열·진통·소염제</td><td>일반</td></tr><tr class="medi"><td>3</td><td><a href="#">어린이타이레놀현탁액_</a></td><td>(주)한국얀센</td><td>해열·진통·소염제</td><td>일반</td></tr><tr class="medi"><td>4</td><td><a href="#">어린이타이레놀현탁액_</a></td><td>(주)한국얀센</td><td>해열·진통·소염제</td><td>일반</td></tr><tr class="medi"><td>5</td><td><a href="#">어린이타이레놀현탁액_</a></td><td>(주)한국얀센</td><td>해열·진통·소염제</td><td>일반</td></tr><tr class="medi"><td>6</td><td><a href="#">어린이타이레놀현탁액_</a></td><td>(주)한국얀센</td><td>해열·진통·소염제</td><td>일반</td></tr><tr class="medi"><td>7</td><td><a href="#">타이레놀옥시캡슐</a></td><td>(주)한국얀센</td><td>합성마약</td><td>전문</td></tr><tr class="medi"><td>8</td><td><a href="#">타이레놀8시간이알서방정</a></td><td>(주)한국얀센</td><td>해열·진통·소염제</td><td>일반</td></tr><tr class="medi"><td>9</td><td><a href="#">타이레놀8시간이알서방정325밀리그람</a></td><td>(주)한국얀센</td><td>해열·진통·소염제</td><td>일반</td></tr><tr class="medi"><td>10</td><td><a href="#">타이레놀정160밀리그람</a></td><td>(주)한국얀센</td><td>해열·진통·소염제</td><td>일반</td></tr>
                </table>
                <div class="numer_nav">
                    <div class="pagination">
                        <a href="#">&laquo;</a>
                        <a href="#" class="n_nav_select">1</a>
                        <a href="#">2</a>
                        <a href="#">3</a>
                        <a href="#">4</a>
                        <a href="#">5</a>
                        <a href="#">6</a>
                        <a href="#">&raquo;</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>
</html>

<script>
    var evtSource;

    function handleKeyPress(event) {
        if (event.key === 'Enter') {
            searchMedicine();
        }
    }

    function searchMedicine() {
        const searchKeywordElem = document.getElementById("searchKeyword");
        const inputQuestionElem = document.getElementById("inputQuestion");
        
        inputQuestionElem.value = searchKeywordElem.value; // 복사
        
        // questionForm의 submit 이벤트를 직접 호출
        const event = new Event('submit', {
            'bubbles': true,
            'cancelable': true
        });
        questionForm.dispatchEvent(event);

        var selectedOption = document.getElementById("searchOption").value;
        var keyword = searchKeywordElem.value;

        // AJAX 요청을 보냄
        $.ajax({
            type: "GET",
            url: "./lib/med_search_ajax.php", // PHP 스크립트 파일 경로
            data: {
                searchOption: selectedOption,
                searchKeyword: keyword
            },
            success: function(response) {
                $("#medicineTable tr:not(:first)").remove(); // 기존 테이블 내용 삭제
                $("#medicineTable").append(response); // 새로운 데이터로 업데이트
            },
            error: function() {
                alert("검색 중 오류가 발생했습니다.");
            }
        });
    }

    const questionForm = document.getElementById("questionForm");
const responseDiv = document.getElementById("response");
const waitingMessage = document.getElementById("waitingMessage");

questionForm.addEventListener("submit", function(event) {
    event.preventDefault();
    const question = document.getElementById("inputQuestion").value;

    if (question) {
        waitingMessage.style.display = "block";
        responseDiv.textContent = "";

        evtSource = new EventSource("gpt_server.php?question=" + encodeURIComponent(question)); // <-- 2. 'const' 키워드 제거
        evtSource.onmessage = function(event) {
            const responseData = JSON.parse(event.data);
            
            // 타이핑 효과 추가
            let typingIdx = 0;
            let typingTxt = responseData.choices[0].text.trim().split("");
            function typing() {
                if (typingIdx < typingTxt.length) {
                    responseDiv.append(typingTxt[typingIdx]);
                    typingIdx++;
                } else {
                    clearInterval(tyInt);
                }
            }
            var tyInt = setInterval(typing, 10);

            waitingMessage.style.display = "none";
            evtSource.close();
        };
    }
});

    var typingBool = false; 
var typingIdx = 0; 
var typingTxt = ""; 

function startTypingEffect(text) {
    typingTxt = text.split("");
    typingBool = true;
    typing();
}

function typing() { 
    if (typingIdx < typingTxt.length) { 
        document.getElementById("response").innerHTML += typingTxt[typingIdx];
        typingIdx++; 
        setTimeout(typing, 100); // 반복동작
    } 
}

evtSource.onmessage = function(event) {
    const responseData = JSON.parse(event.data);
    const responseText = responseData.choices[0].text.trim();
    document.getElementById("response").innerHTML = ""; // 결과 영역 초기화
    typingIdx = 0; // 타이핑 인덱스 초기화
    startTypingEffect(responseText); // 타이핑 효과 시작
    waitingMessage.style.display = "none";
};



</script>
