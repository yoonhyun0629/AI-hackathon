<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>AI 처방전</title>
    <link rel="stylesheet" type="text/css" href="./css/main.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
    #inputQuestion, #questionForm button {
        display: none;
    }
    .typing {  
        display: inline-block; 
        animation-name: cursor; 
        animation-duration: 0.3s; 
        animation-iteration-count: infinite; 
    } 

</style>
</head>
<body>
    <?php include './lib/header.php';?>
    <section class="info_section">
        <div class="info_text">
            <p>AI Prescription</p>
            <p>ChatGPT 기반의 의약품 처방 가이드 솔루션</p>
        </div>
    </section>
    <section class="menu_list">
        <div class="menu_array">
            <ul>
                <li><a href="#">솔루션</a></li>
                <li><a href="./med_search.php">의약품 조회</a></li>
                <li><a href="./chat_gpt.php"  class="select_menu">AI 처방전</a></li>
            </ul>
        </div>
    </section>
    <section class="title_section">
        <div class="title_box">
            <p class="s_title">AI 처방전</p>
            <i class="under_line">&nbsp;</i>
            <p class="s_title_info">자신의 상태나 복용하는 약을 물어보세요.</p>
        </div>
    </section>
    <section class="gpt_section">
        <div class="gpt_wrap">
            <div class="gpt_chat_box">
                <div class="gpt_chat_logo">
                    <p><img src="./assets/images/logo.png"></p>
                </div>
                <div class="gpt_chat_list">
                    <ul style="overflow:scroll;" class="chat_ul">
                        <li class="chat_ai">
                            <div class="chat_ai_logo">
                                <p><img src="./assets/images/gpt.png"></p>
                            </div>
                            <div class="chat_ai_text first">
                                <p>안녕하세요 인공지능 AI-Pharm입니다. 당신의 몸 상태와 증상을 말씀해주시면 증상에 맞는 약을 알려드립니다. 또한 복용하는 약이 있을 경우 포함해서 얘기해주세요.</p>
                            </div>
                        </li>
                    </ul>
                    <div class="gpt_input">
                        <div class="gpt_input_box">
                            <input type="text" id="userMessageInput" name="" onkeydown="checkEnter(event)" placeholder="내용을 입력해주세요.">
                            <button type="submit" onclick="addUserMessage()"><img src="./assets/images/send.svg" alt=""></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>
</html>
<script>
    let typingTxt = "";
    let typingIdx = 0;

    function startTypingEffect(element, text) {
        typingTxt = text.split("");
        typingIdx = 0;
        typing(element);
        element.classList.add("typing");
    }

    function typing(element) { 
        if (typingIdx < typingTxt.length) { 
            element.innerHTML += typingTxt[typingIdx];
            typingIdx++; 
            setTimeout(function() {
                typing(element);
            }, 30);
        } else {
            element.classList.remove("typing");
        }
    }

    function addUserMessage() {
        const userInput = document.getElementById("userMessageInput").value;

        if (userInput) {
            const newLi = document.createElement("li");
            newLi.className = "chat_me";
            newLi.innerHTML = `<p>${userInput}</p>`;
            const chatUl = document.querySelector(".chat_ul");
            chatUl.appendChild(newLi);
            document.getElementById("userMessageInput").value = "";
            requestAIResponse(userInput);
        }
    }

    function requestAIResponse(question) {
        const loadingLi = document.createElement("li");
        loadingLi.className = "chat_ai";
        loadingLi.innerHTML = `
            <div class="chat_ai_logo">
                <p><img src="./assets/images/gpt.png"></p>
            </div>
            <div class="chat_ai_text">
                <p>AI-Pharm 입력하고 있습니다..</p>
            </div>`;
        const chatUl = document.querySelector(".chat_ul");
        chatUl.appendChild(loadingLi);
        const userMessageInput = document.getElementById("userMessageInput");
        userMessageInput.placeholder = "AI가 말하고 있습니다";
        userMessageInput.disabled = true;

        const evtSource = new EventSource("gpt_server2.php?question=" + encodeURIComponent(question));
        evtSource.onmessage = function(event) {
            const responseData = JSON.parse(event.data);
            const aiResponse = responseData.choices[0].text.trim();
            loadingLi.querySelector(".chat_ai_text p").textContent = "";
            startTypingEffect(loadingLi.querySelector(".chat_ai_text p"), aiResponse);
            userMessageInput.placeholder = "내용을 입력해주세요.";
            userMessageInput.disabled = false;

            evtSource.close();
        };
    }

    function checkEnter(event) {
        if (event.keyCode === 13) {
            addUserMessage();
        }
    }

    window.onload = function() {
        const initialMsgElement = document.querySelector(".chat_ai_text.first p");
        const initialMessage = initialMsgElement.textContent;
        initialMsgElement.textContent = "";
        startTypingEffect(initialMsgElement, initialMessage);
    };

</script>
