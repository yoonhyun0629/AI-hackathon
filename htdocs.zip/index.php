<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>AI-Pharm</title>
	<link rel="stylesheet" type="text/css" href="./css/main.css">
</head>
<body>
	<header>
		<div class="header_wrap">
			<ul class="haeder_ul">
				<li class="logo">
					<a href="#"><img src="./assets/images/logo.png"></a>
				</li>
				<li class="menu">
					<nav>
						<ul>
							<li class="blue_hover"><a href="#">솔루션</a></li>
							<li class="red_hover"><a href="#">의약품 조회<i class="circle red">&nbsp;</i></a></li>
							<li class="blue_hover"><a href="#">AI 처방전<i class="circle blue">&nbsp;</i></a></li>
						</ul>
					</nav>
				</li>
				<li class="login">
					<ul>
						<li><a href="#">LOGIN</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</header>
	<section class="main_section">
		<div class="main_left">
			<div class="main_left_wrap">
				<div class="main_left_box">
					<p class="main_title"><span class="blue_f">Medication Prescription</span> Guide<br>Solution Provider based on <span class="red_f">ChatGPT</span></p>
					<p class="main_info">ChatGPT 기반의 의약품 처방 가이드 솔루션 제공자로서, ICT 솔루션을 활용하여 온라인 및 오프라인에서 <br>전례 없는 새로운 의약품 처방 경험과 문화를 실현합니다.</p>
					<div class="main_btn">
						<a href="https://naver.com" class="btn red hover_btn_r">솔루션 체험하기</a>
						<a href="#" class="btn blue hover_btn_b">의약품 조회</a>
					</div>
				</div>
			</div>
		</div>
	</section>
</body>
</html>