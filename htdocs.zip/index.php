<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>AI-Pharm</title>
	<link rel="stylesheet" type="text/css" href="./css/main.css">
</head>
<body class="main_body">
	<?php include './lib/header.php';?>
	<section class="main_section">
		<div class="main_left">
			<div class="main_left_wrap">
				<div class="main_left_box">
					<p class="main_title"><span class="blue_f">Medication Prescription</span> Guide<br>Solution Provider based on <span class="red_f">ChatGPT</span></p>
					<p class="main_info">ChatGPT 기반의 의약품 처방 가이드 솔루션 제공자로서, ICT 솔루션을 활용하여 온라인 및 오프라인에서 <br>전례 없는 새로운 의약품 처방 경험과 문화를 실현합니다.</p>
					<div class="main_btn">
						<a href="./chat_gpt.php" class="btn blue hover_btn_b">솔루션 체험하기</a>
						<a href="./med_search.php" class="btn red hover_btn_r">의약품 조회</a>
					</div>
				</div>
			</div>
		</div>
	</section>
</body>
</html>